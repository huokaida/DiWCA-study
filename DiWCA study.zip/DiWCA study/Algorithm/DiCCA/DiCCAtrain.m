function [Model] = DiCCAtrain(X,s,CPVd,CPVs,e)
% X:data matrix  s:order of AR model  e:convergence e
% Model:DiCCA model
[N,M] = size(X);
if N <= M
    error('N <= M in X!');
end
if nargin < 5
    e = 1e-4;
end
if nargin < 4
    CPVs = 0.95;
end
if nargin < 4
    CPVd = 0.95;
end
W = zeros(M,M); % projection vectors
B = zeros(s,M); % regression coffecients
T = zeros(N,M); % latent scores
T_hat = zeros(N - s,M); % predicted scores
P = zeros(M,M); % loading vectors
Vars = zeros(1,M);  % variances
R2s = zeros(1,M);   % R2 values
etas_v = zeros(1,M);    % v whiteness
etas_e = zeros(1,M);    % e whiteness
Q = generateQ(N - s);
% LV finding
X_ = X;
k = 0;
while k < M
    k = k + 1;
    [W(:,k),T(:,k),P(:,k),B(:,k),R2s(k)] = DiCCA_LVfinding(X_,s,e);
    Vars(k) = T(:,k)' * T(:,k) / (N - 1);
    for j = 1:s
        T_hat(:,k) = T_hat(:,k) + B(j,k) * T(s + 1 - j:N - j,k);
    end
    etas_v(k) = Whiteness(T(s + 1:N,k) - T_hat(:,k),Q);
    % deflation
    X_ = X_ - T(:,k) * P(:,k)';
end
% V_all
V_all.V = W / (P' * W);
V_all.IndexNames = {'{\rm{Var}}(t_i)','R^2','\rho(v_i)','\rho(e_i)'};
V_all.Indices = cell(1,length(V_all.IndexNames));
V_all.Indices{1} = Vars;
V_all.Indices{2} = R2s;
V_all.Indices{3} = etas_v;
% partition
varsR2s = Vars .* R2s;
Var_all = sum(Vars);
for k = M - 1:-1:1
    if sum(varsR2s(M:-1:k)) > (1 - CPVd) * Var_all
        break;
    end
end
W = W(:,1:k);
B = B(:,1:k);
T = T(:,1:k);
T_hat = T_hat(:,1:k);
P = P(:,1:k);
E = X(s + 1:N,:) - T_hat * P';
Er = X(s + 1:N,:) - T(s + 1:N,:) * P';
Ev = T(s + 1:N,:) - T_hat;
for k = 1:M
    etas_e(k) = Whiteness(E(:,k),Q);
end
V_all.Indices{4} = etas_e;
% static PCA upon residual matrix
[HalfCoreTe2,HalfCoreQe,ge] = generatePCAHalfcore(E,CPVs);
[HalfCoreTr2,HalfCoreQr,gr] = generatePCAHalfcore(Er,CPVs);
[HalfCoreTv2,HalfCoreQv,gv] = generatePCAHalfcore(Ev,CPVs);
% integrate Model
Model.R = W / (P' * W);
Model.P = P;
Model.B = B;
Model.HalfCoreTe2 = HalfCoreTe2;
Model.HalfCoreQe = HalfCoreQe;
Model.ge = ge;
Model.HalfCoreTr2 = HalfCoreTr2;
Model.HalfCoreQr = HalfCoreQr;
Model.gr = gr;
Model.HalfCoreTv2 = HalfCoreTv2;
Model.HalfCoreQv = HalfCoreQv;
Model.gv = gv;
Model.V_all = V_all;
return;
end


function [w_opt,t_opt,p_opt,b_opt,Jmax] = DiCCA_LVfinding(X,s,e)
% solve DiCCA optimization
N = size(X,1);
w0s = initialize_ws(X,'PCA');
numc = size(w0s,2);
Jmax = -Inf;
for i = 1:numc
    w_ = w0s(:,i);
    b_ = bindb2w(X,w_,s);
    convergence = false;
    time = 0;
    maxtime = 1000;
    while ~convergence && time <= maxtime
        time = time + 1;
        w = bindw2b(X,b_);
        b = bindb2w(X,w,s);
        convergence = norm(w - w_) < e && norm(b - b_) < e;
        w_ = w;
        b_ = b;
    end
    t = X * w;
    Ht = zeros(N - s,s);
    for j = 1:s
        Ht(:,j) = t(s + 1 - j:N - j);
    end
    t_hat = Ht * b;
    J = t_hat' * t(s + 1:N) / (norm(t_hat) * norm(t(s + 1:N)));
    if J > Jmax
        Jmax = J;
        w_opt = w;
        b_opt = b;
        t_opt = t;
        t_hat_opt = t_hat;
    end
end
disp(['angle = ',num2str(Jmax)]);
p_opt = X' * t_opt / (t_opt' * t_opt);
% rescale
t_opt = t_opt * norm(p_opt);
w_opt = w_opt * norm(p_opt);
p_opt = p_opt / norm(p_opt);
return;
end


function [b] = bindb2w(X,w,s)
% bind b to w
% b = argmin_{b} norm(t - H[t] * b)  s.t.  t = X_ * q  norm(t) = norm(H[t] * b)
N = size(X,1);
t_withs = X * w;
Ht = zeros(N - s,s);
for i = 1:s
    Ht(:,i) = t_withs(s + 1 - i:N - i);
end
t = t_withs(s + 1:N);
h = Ht' * t;
invH = inv(Ht' * Ht);
lambda = sqrt((h' * invH * h) / (t' * t));
b = invH * h / lambda;
return;
end


function [w] = bindw2b(X,b)
% bind w to b
s = length(b);
[N,m] = size(X);
X_b = zeros(N - s,m);
for i = 1:s
    X_b = X_b + b(i) * X(s + 1 - i:N - i,:);
end
X_s = X(s + 1:N,:);
A = pinv(X_s' * X_s + X_b' * X_b) * (X_s' * X_b + X_b' * X_s);
[qs,D] = eig(A);
d = diag(D);
I = find(d == max(d));
w = qs(:,I(1));
return;
end


function [w0s] = initialize_ws(X,mode)
% determine initial point
if strcmp(mode,'PCA')
    [~,~,w0s] = svd(X);
end
if strcmp(mode,'r') % random
    M = size(X,2);
    n = ceil(str2double(mode(2:length(mode))));
    w0s = zeros(M,n);
    for i = 1:n
        w0 = randn(M,1);
        w0s(:,i) = w0 / norm(w0);
    end
end
return;
end


function [HalfCoreT2,HalfCoreQ,g] = generatePCAHalfcore(X,CPVs)
% Generate Halfcore matrices for indices' calculation (statistic = e' * Core * e)
[N,M] = size(X);
[~,S,V] = svd(X);
ss = diag(S) .^ 2;
for Ms = M:-1:1
    if sum(ss(M:-1:Ms)) > (1 - CPVs) * sum(ss)
        break;
    end
end
ss = ss / (N - 1);
Pd = V(:,1:Ms);
Pe = V(:,Ms + 1:M);
ssd = ss(1:Ms);
sse = ss(Ms + 1:M);
if Ms == M
    g = 0;
else
    g = sum(sse) / sum(sse .^ 2);
end
HalfCoreT2 = diag(1 ./ sqrt(ssd)) * Pd';
HalfCoreQ = Pe';
return;
end