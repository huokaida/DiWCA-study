function [Indices,CLs] = monitoringDiWCA(xs,Model,L,cl,Names)
% monitoring based on DiWCA
% xs:data matrix for test  
% Model:DiWCA LV model  
% L:width of window  
% cl:confidence level for judging control limits
% Names:statistics' names
% Indices:statistics' names and curves
% CLs:control limits
if nargin < 4
    cl = 0.95;
end
[N,M] = size(xs);
T = xs * Model.R;
Ms = size(T,2);
s = size(Model.B,1);
% inner prediction
T_hat = zeros(N - s,Ms);
for k = 1:Ms
    for j = 1:s
        T_hat(:,k) = T_hat(:,k) + Model.B(j,k) * T(s + 1 - j:N - j,k);
    end
end
% monitor
E = xs(s + 1:N,:) - T_hat * Model.P';
Er = xs(s + 1:N,:) - T(s + 1:N,:) * Model.P';   % static residual
Ev = T(s + 1:N,:) - T_hat;  % dynamic residual
if nargin < 5
    Indices.Names = {'\phi_v','\phi_r','W_v','W_r'};
else
    Indices.Names = Names;
end
Indices.indexcurves = cell(1,length(Indices.Names));
for id = 1:length(Indices.Names)
    % phi_e statistic
    if strcmp(Indices.Names{id},'\phi_e')
        phi_e = NaN * zeros(N,1);
        for k = s + 1:N
            t = Model.HalfCoreTe2 * E(k - s,:)';
            t_ = Model.HalfCoreQe * E(k - s,:)';
            phi_e(k) = t' * t + Model.ge * (t_' * t_);
        end
        Indices.indexcurves{id} = phi_e;
    end
    % phi_r statistic
    if strcmp(Indices.Names{id},'\phi_r')
        phi_r = NaN * zeros(N,1);
        for k = s + 1:N
            t = Model.HalfCoreTr2 * Er(k - s,:)';
            t_ = Model.HalfCoreQr * Er(k - s,:)';
            phi_r(k) = t' * t + Model.gr * (t_' * t_);
        end
        Indices.indexcurves{id} = phi_r;
    end
    % phi_v statistic
    if strcmp(Indices.Names{id},'\phi_v')
        phi_v = NaN * zeros(N,1);
        for k = s + 1:N
            t = Model.HalfCoreTv2 * Ev(k - s,:)';
            t_ = Model.HalfCoreQv * Ev(k - s,:)';
            phi_v(k) = t' * t + Model.gv * (t_' * t_);
        end
        Indices.indexcurves{id} = phi_v;
    end
    % Tr2 statistic
    if strcmp(Indices.Names{id},'T_r^2')
        Tr2 = NaN * zeros(N,1);
        for k = s + 1:N
            t = Model.HalfCoreTr2 * Er(k - s,:)';
            Tr2(k) = t' * t;
        end
        Indices.indexcurves{id} = Tr2;
    end
    % Qr statistic
    if strcmp(Indices.Names{id},'Q_r')
        Qr = NaN * zeros(N,1);
        for k = s + 1:N
            t_ = Model.HalfCoreQr * Er(k - s,:)';
            Qr(k) = t_' * t_;
        end
        Indices.indexcurves{id} = Qr;
    end
    % W_r statistic
    if strcmp(Indices.Names{id},'W_r')
        Q = generateQ(L + 1);
        W_r = NaN * zeros(N,1);
        for k = s + 1 + L:N
            wr = 0;
            for j = 1:M
                wr = wr + Whiteness(Er(k - s - L:k - s,j)',Q);
            end
            W_r(k) = wr / M;
        end
        Indices.indexcurves{id} = W_r;
    end
    % W_v statistic
    if strcmp(Indices.Names{id},'W_v')
        Q = generateQ(L + 1);
        W_v = NaN * zeros(N,1);
        for k = s + 1 + L:N
            wv = 0;
            for j = 1:Ms
                wv = wv + Whiteness(Ev(k - s - L:k - s,j)',Q);
            end
            W_v(k) = wv / Ms;
        end
        Indices.indexcurves{id} = W_v;
    end
end
% determine control limits
CLs = zeros(1,length(Indices.indexcurves));
% figure();
for i = 1:length(Indices.indexcurves)
    indexcurve = Indices.indexcurves{i};
%     subplot(length(Indices.indexcurves),1,i);
%     plot(indexcurve);
    indexvalues = indexcurve(~isnan(indexcurve));
    indexvalues = sort(indexvalues);
    CLs(i) = indexvalues(floor(cl * length(indexvalues)));
%     I = find(indexcurve > (max(indexcurve) - min(indexcurve)) * cl + min(indexcurve));
%     CLs(i) = min(indexcurve(I));
end
return;
end