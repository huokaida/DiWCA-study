function [Q] = generateQ(N)
% generate Q matrices
% N: signal length
Q = cell(N - 1,1);
Q{1} = ones(N,N);
for k = 1:N - 2
    zz = zeros(N,N);
    values = cos(2 * pi * (1:N - 1) * k / N);
    for p = 1:N
        zz(p,p) = 1;
        for q = p + 1:N
            zz(p,q) = values(q - p);
            zz(q,p) = values(q - p);
        end
    end
    Q{k+1} = Q{k} + zz;
end
for k = 1:N - 1
    Q{k} = Q{k} / N - k / N * eye(N);
end
return;
end

