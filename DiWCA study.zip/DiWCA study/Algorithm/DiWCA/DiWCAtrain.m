function [Model] = DiWCAtrain(X,s,st,CPVs)
% X:Data Matrix threshold  CPVs:
% s:Order of latent AR model
% st:CPPV threshold (CPPV = 1 - st)
% CPVs:CPV for PCA upon static residuals
% Model:Model
if nargin < 4
    CPVs = 0.95;
end
if nargin < 3
    st = 0.05;
end
[N,M] = size(X);
if N <= M
    error('N <= M in X!');
end
V = zeros(M,M); % nondeflation projection vectors
B = zeros(s,M); % regression coffecients
T = zeros(N,M); % latent scores
T_hat = zeros(N - s,M); % predicted scores
W = zeros(M,M); % deflation projection vectors
P = zeros(M,M); % deflation loading vectors
Vars = NaN * zeros(1,M);  % variances
R2s = NaN * zeros(1,M);   % R2 values
varsR2s = NaN * zeros(1,M);
% etas_vsi = NaN * zeros(1,M);    % v whiteness_si
etas_v = NaN * zeros(1,M);    % v whiteness
etas_e = NaN * zeros(1,M);    % e whiteness

Qo = generateQ(N - s);  % Q matrices for calculating whiteness index
Q = Qo;
eyeN_s = eye(N - s);
gamma = 1;
for k = 1:length(Q)
    Q{k} = Q{k} + gamma * eyeN_s;
end

% LVs finding
Phi = eye(M);
G = eye(M);
X_ = X;
CovX = (X' * X) / (N - 1);
for k = 1:M
    % determine initial point
    XPhi = X * Phi;
    [q0,b0] = initialize(XPhi,s,'DiCCA');
    % solve minmax problem using ADMM
    [q,b] = minmaxSolver(XPhi,Q,q0,b0);
    q = q / norm(q);
    V(:,k) = Phi * q;
    B(:,k) = b;
%     etas_vsi(k) = max(J / (1 - J) - gamma,0);
    % update matrices and do deflation
    [Phi,~,~] = svd(CovX * V(:,1:k));
    Phi = Phi(:,k + 1:M);
    W(:,k) = G \ V(:,k);
    T(:,k) = X * V(:,k);
    P(:,k) = X_' * T(:,k) / (T(:,k)' * T(:,k));
    G = G * (eye(M) - W(:,k) * P(:,k)');
    X_ = X_ - T(:,k) * P(:,k)';
    % rescale
    V(:,k) = V(:,k) * norm(P(:,k));
    T(:,k) = T(:,k) * norm(P(:,k));
    W(:,k) = W(:,k) * norm(P(:,k));
    P(:,k) = P(:,k) / norm(P(:,k));
    % prediction
    for j = 1:s
        T_hat(:,k) = T_hat(:,k) + B(j,k) * T(s + 1 - j:N - j,k);
    end
    Vars(k) = T(:,k)' * T(:,k) / (N - 1);
    R2s(k) = T_hat(:,k)' * T(s + 1:N,k) / (norm(T_hat(:,k)) * norm(T(s + 1:N,k)));
    varsR2s(k) = T_hat(:,k)' * T_hat(:,k) / (N - s - 1);
    etas_v(k) = Whiteness(T(s + 1:N,k) - T_hat(:,k),Qo);
end
% resort LVs according to whiteness
R = W / (P' * W);
[etas_v,I] = sort(etas_v);
Vars = Vars(I);
varsR2s = varsR2s(I);
R2s = R2s(I);
R = R(:,I);
P = P(:,I);
B = B(:,I);
T = T(:,I);
T_hat = T_hat(:,I);
% determine l according to CPPV
Var_all = sum(Vars);
for k = 1:M - 1
    if sum(varsR2s(1:k)) >= (1 - st) * Var_all
        break;
    end
end
R = R(:,1:k);
B = B(:,1:k);
T = T(:,1:k);
T_hat = T_hat(:,1:k);
P = P(:,1:k);
E = X(s + 1:N,:) - T_hat * P';
Er = X(s + 1:N,:) - T(s + 1:N,:) * P';
Ev = T(s + 1:N,:) - T_hat;
for k = 1:M
    etas_e(k) = Whiteness(E(:,k),Qo);
end
% V_all
V_all.IndexNames = {'{\rm{Var}}(t_i)','R^2','\rho(v_i)','\rho(e_i)'};
V_all.Indices = cell(1,length(V_all.IndexNames));
V_all.Indices{1} = Vars;
V_all.Indices{2} = R2s;
V_all.Indices{3} = etas_v;
V_all.Indices{4} = etas_e;
% static PCA upon residual matrix
[HalfCoreTe2,HalfCoreQe,ge] = generatePCAHalfcore(E,CPVs);
[HalfCoreTr2,HalfCoreQr,gr] = generatePCAHalfcore(Er,CPVs);
[HalfCoreTv2,HalfCoreQv,gv] = generatePCAHalfcore(Ev,CPVs);
% integrate Model
Model.R = R;
Model.P = P;
Model.B = B;
Model.HalfCoreTe2 = HalfCoreTe2;
Model.HalfCoreQe = HalfCoreQe;
Model.ge = ge;
Model.HalfCoreTr2 = HalfCoreTr2;
Model.HalfCoreQr = HalfCoreQr;
Model.gr = gr;
Model.HalfCoreTv2 = HalfCoreTv2;
Model.HalfCoreQv = HalfCoreQv;
Model.gv = gv;
Model.V_all = V_all;
return;
end


function [q0,b0] = initialize(X,s,type)
% determine initial point of minmax problem
if strcmp(type,'PCA')
    [qs,D] = eig(X' * X);
    d = diag(D);
    I = find(d == max(d));
    q0 = qs(:,I(1));
    q0 = q0 / norm(q0);
    b0 = bindb2q(X,q0,s);
end
if strcmp(type,'DiCCA')
    [q0,b0] = DiCCA_LVfinding(X,s);
    q0 = q0 / norm(q0);
end
return;
end


function [b] = bindb2q(X,q,s)
% b = argmin_{b} norm(t - H[t] * b)  s.t.  t = X * q  norm(t) = norm(H[t] * b)
N = size(X,1);
t_withs = X * q;
Ht = zeros(N - s,s);
for i = 1:s
    Ht(:,i) = t_withs(s + 1 - i:N - i);
end
t = t_withs(s + 1:N);
h = Ht' * t;
invH = inv(Ht' * Ht);
lambda = sqrt((h' * invH * h) / (t' * t));
b = invH * h / lambda;
return;
end


function [w_opt,b_opt] = DiCCA_LVfinding(X,s)
% solve DiCCA problem
e = 1e-4;
N = size(X,1);
[~,~,w0s] = svd(X);
numc = size(w0s,2);
Jmax = -Inf;
for i = 1:numc
    w_ = w0s(:,i);
    b_ = bindb2q(X,w_,s);
    convergence = false;
    time = 0;
    maxtime = 1000;
    while ~convergence && time <= maxtime
        time = time + 1;
        w = bindw2b(X,b_);
        b = bindb2q(X,w,s);
        convergence = norm(w - w_) < e && norm(b - b_) < e;
        w_ = w;
        b_ = b;
    end
    t = X * w;
    Ht = zeros(N - s,s);
    for j = 1:s
        Ht(:,j) = t(s + 1 - j:N - j);
    end
    t_hat = Ht * b;
    J = t_hat' * t(s + 1:N) / (norm(t_hat) * norm(t(s + 1:N)));
    if J > Jmax
        Jmax = J;
        w_opt = w;
        b_opt = b;
    end
end
return;
end


function [w] = bindw2b(X,b)
% bind w to b in DiCCA
s = length(b);
[N,m] = size(X);
X_b = zeros(N - s,m);
for i = 1:s
    X_b = X_b + b(i) * X(s + 1 - i:N - i,:);
end
X_s = X(s + 1:N,:);
A = pinv(X_s' * X_s + X_b' * X_b) * (X_s' * X_b + X_b' * X_s);
[qs,D] = eig(A);
d = diag(D);
I = find(d == max(d));
w = qs(:,I(1));
return;
end


function [q,b,t,J] = minmaxSolver(X,Q,q0,b0)
% solve minmax problem: min_{q} whiteness(Z_b * q) s.t. q' * q = 1
% q0:initial projection vector  b0:initial AR coefficients

n = length(q0);
Nq = length(Q);
[N,M] = size(X);
s = length(b0);
Z_b = zeros(N - s,M);
for k = s + 1:N
    Z_b(k - s,:) = b0' * X(k - 1:-1:k - s,:);
end
Z_b = X(s + 1:N,:) - Z_b;
v = Z_b * q0;   % initial prediction error
Varv = v' * v;
etagamma = -Inf;    % whiteness(prediction error) + gamma
for m = 1:Nq
    Rm = (v' * Q{m} * v) / Varv;
    if Rm > etagamma
        etagamma = Rm;
    end
end
tau = etagamma / (etagamma + 1);
t = sqrt(tau);
q0 = sqrt((1 - tau) / Varv) * q0;
z0 = [q0;t];
S = zeros(n + 1,n + 1);
S(n + 1,n + 1) = 1;
maxtime = 10000;
alpha = 5;
[z,b,J] = ADMMQCQP_for_DiWCA(S,X,Q,alpha,z0,b0,maxtime);    %ADMM
q = z(1:n);
t = z(n + 1);
return;
end


function [HalfCoreT2,HalfCoreQ,g] = generatePCAHalfcore(X,CPVs)
% Generate Halfcore matrices for indices' calculation (statistic = e' * Core * e)
[N,M] = size(X);
[~,S,V] = svd(X);
ss = diag(S) .^ 2;
for Ms = M:-1:1
    if sum(ss(M:-1:Ms)) > (1 - CPVs) * sum(ss)
        break;
    end
end
ss = ss / (N - 1);
Pd = V(:,1:Ms);
Pe = V(:,Ms + 1:M);
ssd = ss(1:Ms);
sse = ss(Ms + 1:M);
if Ms == M
    g = 0;
else
    g = sum(sse) / sum(sse .^ 2);
end
HalfCoreT2 = diag(1 ./ sqrt(ssd)) * Pd';
HalfCoreQ = Pe';
return;
end