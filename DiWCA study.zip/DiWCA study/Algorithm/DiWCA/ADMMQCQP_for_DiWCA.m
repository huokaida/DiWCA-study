function [x_best,b_best,J_best,Js,Jeta_bests] = ADMMQCQP_for_DiWCA(P,X_,Q,alpha,x0,b0,maxtime)
% Using ADMM solve:
% min x' * P * x  s.t.  x' * S_ine(b){i} * x <= K(i)  x' * S_e(b) * x == 1
% maxtime:max number of iterations

surplus = 0.5;
[n,n_] = size(P);
if n ~= n_
    error('P is not square!');
end

lminP = min(eig(P));
P0 = P;
if lminP <= 0
    P = P0 + (abs(lminP) + surplus) * eye(n);
end
% form S matrices and unitize z
[Se,S_ine,K,Trans_qt_to_z] = formS(X_,Q,b0,surplus);
z0 = Trans_qt_to_z * x0;
% initial point
z_ = z0;
x_ = z_;
u_ = zeros(n,1);
% convergence e
e_rel = 1e-3;
e_abs = 1e-6;
e_pri = -1;
e_dual = -1;
% temporal
d = 1 ./ sqrt(diag(P) + alpha);
D = diag(d);
% residuals
r = 0;
s = 0;
% optimize
time = 0;
feasibletime = 0;
Isfeasible = true;
m = length(Q);
for i = 1:m
    if z_' * S_ine{i} * z_ - K(i) > 1e-5
        Isfeasible = false;
        break;
    end
end
if Isfeasible
    J_best = z_' * P0 * z_;
    x_best = x0;
    b = b0;
    b_best = b;
else
    J_best = Inf;
    x_best = x0;
    b = b0;
    b_best = b;
end
mineta = J_best / (1 - J_best) - 1;
Js = zeros(1,maxtime);
Js_eta = zeros(1,maxtime);
Jeta_bests = zeros(1,maxtime);
while r > e_pri || s > e_dual
    % update z
    [U,Sigma] = eig(D * Se * D);
    dSigama = diag(Sigma);
    zeta = alpha * U' * D * (x_ - u_);
    v = SolveKKTe(zeta,dSigama);
    if ~isnan(v)
        z = D * U * diag(1 ./ (1 + v * dSigama)) * zeta;
        if abs(z' * z - 1) > 1e-3
            v = SolveKKT(zeta,1 ./ dSigama);
            z = D * U * diag(1 ./ (1 + v * dSigama)) * zeta;
            if abs(z' * z - 1) > 1e-3
                z = z / norm(z);
            end
        end
    else
        v = SolveKKT(zeta,1 ./ dSigama);
        z = D * U * diag(1 ./ (1 + v * dSigama)) * zeta;
        if abs(z' * z - 1) > 1e-3
            z = z / norm(z);
        end
    end
    % update x
    x = z + u_;
    Isfeasible = true;
    u0 = zeros(m,1);
    for i = 1:m
        u0(i) = x' * S_ine{i} * x;
        if u0(i) - K(i) > 1e-10
            Isfeasible = false;
            u0(i) = 0;
        end
    end
    if ~Isfeasible
        e = 0.001;
        DualsolverQPmaxtime = 200;
        x = DualsolverQP(eye(n),-2 * (z + u_),S_ine,K,u0,e,DualsolverQPmaxtime);
    end
    % update u
    u = u_ + 1 * (z - x);
    % prepare for next iteration
    e_pri = sqrt(n) * e_abs + e_rel * max(norm(x),norm(z));
    e_dual = sqrt(n) * e_abs + e_rel * norm(u);
    r = norm(z - x);
    s = norm(alpha * (z - z_));
    z_ = z;
    x_ = x;
    u_ = u;
    % update optimal value
    time = time + 1;
    NumofInfeasible = 0;
    II = zeros(1,m);
    BreakValues = zeros(1,m);
    for i = 1:m
        if z' * S_ine{i} * z > K(i)
            NumofInfeasible = NumofInfeasible + 1;
            II(NumofInfeasible) = i;
            BreakValues(NumofInfeasible) = z' * S_ine{i} * z - K(i);
        end
    end
    II = II(1:NumofInfeasible);
    BreakValues = BreakValues(1:NumofInfeasible);
    J_ = z' * P0 * z;
    if NumofInfeasible == 0
        feasibletime = feasibletime + 1;
        J = J_;
        record = ['iteration number:',num2str(time),' J = ',num2str(J)];
    else
        J = Inf;
        record = ['iteration number:',num2str(time),' J = ',num2str(z' * P0 * z),'+Inf break subjects:'];
    end
    if isempty(BreakValues)
        J_act = J_;
    else
        J_act = J_ + (1 + surplus) * max(BreakValues);
    end
    eta = J_act / (1 - J_) - 1;
    if eta < mineta
        x_best = Trans_qt_to_z \ z;
        mineta = eta;
        b_best = b;
    end
    Jeta_bests(time) = mineta;
    Js(time) = J;
    Js_eta(time) = eta;
    for i = 1:NumofInfeasible
        recordcontent = [num2str(II(i)),'(',num2str(BreakValues(i)),') '];
        record = [record,recordcontent];
    end
    disp(record);
    disp(['norm(z - x) = ',num2str(norm(z - x))]);
    disp(['current optimal eta = ',num2str(mineta)]);
    kk = find([0,0.02,0.05,0.1,0.2,0.5] < mineta,1,'last');
    WTs = [20,40,50,80,100];
    maxwaittime = WTs(kk);
    if time >= maxtime || (time > maxwaittime && Jeta_bests(time - maxwaittime) == Jeta_bests(time)) || mineta <= 0
        break;
    end
    % update b and S matrices
    if NumofInfeasible == 0
        b = bindb2z(X_,z,length(b0),Trans_qt_to_z);
        [Se,S_ine,K,Trans_qt_to_z] = formS(X_,Q,b,surplus);
    end
end
J_best = (mineta + 1) / (mineta + 2);
Js = Js(1:time);
Jeta_bests = Jeta_bests(1:time);
return;
end


function [b] = bindb2z(X_,z,s,Trans_qt_to_z)
% bind b to z
z = Trans_qt_to_z \ z;
q = z(1:length(z) - 1);
N = size(X_,1);
t_withs = X_ * q;
Ht = zeros(N - s,s);
for i = 1:s
    Ht(:,i) = t_withs(s + 1 - i:N - i);
end
t = t_withs(s + 1:N);
h = Ht' * t;
invH = inv(Ht' * Ht);
lambda = sqrt((h' * invH * h) / (t' * t));
b = invH * h / lambda;
return;
end


function [Se,S_ine,K,Trans_qt_to_z] = formS(X_,Q,b,surplus)
% form S matrices
% X_:data matrix  Q:Q matrices  b:AR coefficients  surplus:gamma

[N,M] = size(X_);
Se = eye(M + 1);
s = length(b);
Z_b = zeros(N - s,M);
for i = s + 1:N
    Z_b(i - s,:) = b' * X_(i - 1:-1:i - s,:);
end
Z_b = X_(s + 1:N,:) - Z_b;
B = Z_b' * Z_b;
[V,D] = eig(B);
B_half = diag(sqrt(diag(D))) * V';
inv_B_half = inv(B_half);
Nq = length(Q);
S_ine = cell(Nq,1);
K = zeros(Nq,1);
eyeN_s = eye(N - s);
ZB = Z_b * inv_B_half;
for i = 1:Nq
    K(i) = 1 + surplus;
    S_ine{i} = [ZB' * (Q{i} + eyeN_s) * ZB,zeros(M,1);zeros(1,M),0] + surplus * Se;
    S_ine{i} = S_ine{i} / K(i);
    K(i) = 1;
end
Trans_qt_to_z = [B_half,zeros(M,1);zeros(1,M),1];
return;
end


function [v] = SolveKKT(zeta,lambda)
% solve KKT conditions for z updation
n = length(lambda);
if sum(lambda > 0) < n
    error('Augmented core matrix is not positive-definite!');
end
% convergence e
ef = 1e-5;
ev = 1e-5;
gamma = zeta.^2 .* lambda;
% 
lambda_values = zeros(n,1);
K = 0;
for i = 1:n
    if ~ismember(lambda(i),lambda_values)
        K = K + 1;
        lambda_values(K) = lambda(i);
        I = find(lambda ~= lambda(i));
        f = 1 - sum(gamma(I) ./ (lambda(I) - lambda(i)).^2);
        if abs(f) <= ef
            v = -lambda(i);
            return;
        end
    end
end
% solve by dichotomy
v_left = max(-lambda);
v_right = max((sqrt(n * max(zeta.^2 ./ lambda)) - 1) * min(lambda),(sqrt(n * max(zeta.^2 ./ lambda)) - 1) * max(lambda));
if v_left >= v_right
    error('left > right!');
end
while abs(f) > ef || abs(v_right - v_left) > ev
    v = (v_right + v_left) / 2;
    f = 1 - sum(gamma ./ (v + lambda).^2);
    if f > 0
        v_right = v;
    else
        v_left = v;
    end
end
return;
end


function [v] = SolveKKTe(zeta,sigma)
% solve KKT conditions for z updation
n = length(sigma);
if sum(sigma > 0) < n
    error('Augmented core matrix is not positive-definite!');
end
gamma = zeta.^2 .* sigma;
chs = [sigma .^ 2,2 * sigma,ones(n,1)];
R = chs(1,:);
for i = 2:n
    R = conv(R,chs(i,:));
end
Ls = zeros(n,1 + 2 * n);
for i = 1:n
    ii = [1:i - 1,i + 1:n];
    L = chs(ii(1),:);
    for j = 2:n - 1
        L = conv(L,chs(ii(j),:));
    end
    Ls(i,:) = conv(L,[0,0,gamma(i)]);
end
D = ones(1,n) * Ls - R;
vs = roots(D);
imvs = imag(vs);
revs = real(vs);
I = abs(imvs) < 1e-5;
vs = revs(I);
if isempty(vs)
    v = NaN;
    disp('no real root');
    return;
end
minJ = Inf;
for i = 1:length(vs)
    x = zeta ./ (vs(i) * sigma + 1);
    J = x' * x - 2 * zeta' * x;
    if J < minJ
        minJ = J;
        v = vs(i);
    end
end
return;
end


function [x,u] = DualsolverQP(P,b,A,c,u_,e,maxtime)
% solve  min x' * P * x + b' * x  s.t.  x' * A{k} * x <= c(k)  by solving its dual problem
% u_:initial dual variables  e:convergence e (small gap)
% x:solution of origin problem
% u:solution of dual problem
[n,n_] = size(P);
if n ~= n_
    error('P is not square');
end
N = length(A);
if length(c) ~= N || length(u_) ~= N
    error('***');
end

u = u_;
Q = P;
for k = 1:N
    Q = Q + u(k) * A{k};
end
x = -0.5 * (Q \ b);
J = c' * u + x' * Q * x;
feasible = true;
maxbreak = 0;
for k = 1:N
    BreakValue = x' * A{k} * x - c(k);
    if BreakValue > maxbreak
        maxbreak = BreakValue;
        feasible = false;
    end
end
Jx_ = x' * P * x + b' * x;
if feasible
    Jx = Jx_;
else
    Jx = Inf;
end
gap = Jx + J;
t0 = (log(Jx_ + J + maxbreak) - log(e)) / 100;
time = 0;
acttime = 0;
mingap = gap;
x_best = x;
u_best = u;
while abs(gap) > e && time <= maxtime
    gap_ = gap;
    u_ = u;
    time = time + 1;
    acttime = acttime + 1;
    dgdu = zeros(N,1);
    for k = 1:N
        dgdu(k) = c(k) - x' * A{k} * x;
    end
    direction = dgdu / norm(dgdu);
    % update u,x
    t = t0 / acttime;
    u = u_ - t * direction;
    Ibreak = find(u < 0);
    if ~isempty(Ibreak)
        direction(Ibreak) = zeros(length(Ibreak),1);        
        if norm(direction) > 0
            direction = direction / norm(direction);
        end
        u = u_ - t * direction;
        u(Ibreak) = e / N * ones(length(Ibreak),1);
        Ibreak = find(u < 0);
    end
    Q = P;
    for k = 1:N
        Q = Q + u(k) * A{k};
    end
    x = -0.5 * (Q \ b);
    J = c' * u + x' * Q * x;
    feasible = true;
    for k = 1:N
        if x' * A{k} * x > c(k)
            feasible = false;
        end
    end
    Jx_ = x' * P * x + b' * x;
    if feasible
        Jx = Jx_;
    else
        Jx = Inf;
    end
    gap = Jx + J;
    if gap < 0
        continue;
    end
    if gap < mingap
        mingap = gap;
        x_best = x;
        u_best = u;
    end
    Iun0 = u > e / N;
    if abs(gap_) < Inf && abs(gap) < Inf
        if (gap_ - gap) / t < norm(dgdu(Iun0)) / N
            acttime = 0;
            t0 = (log(Jx_ + J + maxbreak) - log(e)) / 100;
        end
    end
end
x = x_best;
u = u_best;
disp(['gap = ',num2str(mingap),'  times = ',num2str(time)]);
return;
end