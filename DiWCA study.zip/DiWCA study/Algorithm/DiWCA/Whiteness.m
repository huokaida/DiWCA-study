function [eta,eta_up,eta_down,Q] = Whiteness(x,Q)
% calculate whiteness index
% x:signal
% Q:core matrices
N = size(x,1);
if N == 1
    x = x';
    N = size(x,1);
end
if nargin < 2
    Q = generateQ(N);
end
Var = x' * x;
if Var == 0
    eta = 0;
    disp('zero signal');
    return;
end
Delta = zeros(N - 1,1);
for k = 1:N - 1
    Delta(k) = x' * Q{k} * x;
end
eta = max(abs(Delta)) / Var;
eta_up = max(Delta) / Var;
eta_down = max(-Delta) / Var;
return;
end
