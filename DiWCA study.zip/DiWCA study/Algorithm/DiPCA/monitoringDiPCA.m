function [Indices,CLs] = monitoringDiPCA(xs,Model,cl)
% monitoring based on DiCCA
% xs:data matrix for test  
% Model:DiWCA LV model  
% cl:confidence level for judging control limits
% Indices:statistics' names and curves
% CLs:control limits
if nargin < 3
    cl = 0.95;
end
N = size(xs,1);
T = xs * Model.R;
Ms = size(T,2);
s = length(Model.Thetas);
% inner prediction
T_ = zeros(N - s,Ms * s);
Theta = zeros(s * Ms,Ms);
for i = 1:s
    T_(:,(i - 1) * Ms + 1:i * Ms) = T(s + 1 - i:N - i,:);
    Theta((i - 1) * Ms + 1:i * Ms,:) = Model.Thetas{i};
end
T_hat = T_ * Theta;
% monitor
E = xs(s + 1:N,:) - T_hat * Model.P';
Er = xs(s + 1:N,:) - T(s + 1:N,:) * Model.P';
Ev = T(s + 1:N,:) - T_hat;
% Indices.Names = {'\phi_e','\phi_v','\phi_r'};
Indices.Names = {'\phi_v','\phi_r'};
Indices.indexcurves = cell(1,length(Indices.Names));
for id = 1:length(Indices.Names)
    % phi_e statistc
    if strcmp(Indices.Names{id},'\phi_e')
        phi_e = NaN * zeros(N,1);
        for k = s + 1:N
            t = Model.HalfCoreTe2 * E(k - s,:)';
            t_ = Model.HalfCoreQe * E(k - s,:)';
            phi_e(k) = t' * t + Model.ge * (t_' * t_);
        end
        Indices.indexcurves{id} = phi_e;
    end
    % phi_r statistc
    if strcmp(Indices.Names{id},'\phi_r')
        phi_r = NaN * zeros(N,1);
        for k = s + 1:N
            t = Model.HalfCoreTr2 * Er(k - s,:)';
            t_ = Model.HalfCoreQr * Er(k - s,:)';
            phi_r(k) = t' * t + Model.gr * (t_' * t_);
        end
        Indices.indexcurves{id} = phi_r;
    end
    % phi_v statistc
    if strcmp(Indices.Names{id},'\phi_v')
        phi_v = NaN * zeros(N,1);
        for k = s + 1:N
            t = Model.HalfCoreTv2 * Ev(k - s,:)';
            t_ = Model.HalfCoreQv * Ev(k - s,:)';
            phi_v(k) = t' * t + Model.gv * (t_' * t_);
        end
        Indices.indexcurves{id} = phi_v;
    end
    % Tr2 statistc
    if strcmp(Indices.Names{id},'T_r^2')
        Tr2 = NaN * zeros(N,1);
        for k = s + 1:N
            t = Model.HalfCoreTr2 * Er(k - s,:)';
            Tr2(k) = t' * t;
        end
        Indices.indexcurves{id} = Tr2;
    end
    % Qr statistc
    if strcmp(Indices.Names{id},'Q_r')
        Qr = NaN * zeros(N,1);
        for k = s + 1:N
            t_ = Model.HalfCoreQr * Er(k - s,:)';
            Qr(k) = t_' * t_;
        end
        Indices.indexcurves{id} = Qr;
    end
end
% determine control limits
CLs = zeros(1,length(Indices.indexcurves));
% figure();
for i = 1:length(Indices.indexcurves)
    indexcurve = Indices.indexcurves{i};
%     subplot(length(Indices.indexcurves),1,i);
%     plot(indexcurve);
    indexvalues = indexcurve(~isnan(indexcurve));
    indexvalues = sort(indexvalues);
    CLs(i) = indexvalues(floor(cl * length(indexvalues)));
%     I = find(indexcurve > (max(indexcurve) - min(indexcurve)) * cl + min(indexcurve));
%     CLs(i) = min(indexcurve(I));
end
return;
end