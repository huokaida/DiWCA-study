function [] = DrawSPM(ModelNames,Indices,CLs,t_moni,t_fs,t_fe,FontSize,FontSize_axis)
% Plot SPM
if nargin < 8
    FontSize_axis = 14;
end
if nargin < 7
    FontSize = 18;
end
if nargin < 6
    t_fe = NaN;
end
if nargin < 5
    t_fs = NaN;
end
% delete phi_e
for i = 1:length(Indices)
    [~,j] = ismember('\phi_e',Indices{i}.Names);
    if j > 0
        I = [1:(j - 1),(j + 1):length(Indices{i}.Names)];
        Indices{i}.Names = Indices{i}.Names(I);
        Indices{i}.indexcurves = Indices{i}.indexcurves(I);
    end
end
figure();
CL_color = [0.49,0.18,0.56];
cols = length(ModelNames);
rows = 0;
for i = 1:cols
    if length(Indices{i}.Names) > rows
        rows = length(Indices{i}.Names);
    end
end
if cols == 2
    width = (1 - cols * 0.1) / cols;
end
if cols == 3
    width = (1 - cols * 0.085) / cols;
end
if cols == 4
    width = (1 - cols * 0.07) / cols;
end
height = (1 - rows * 0.11) / rows;
mg_rate = 1;
gap_width = (1 - cols * width) / (cols - 1 + 2 * mg_rate);
margin_width = mg_rate * gap_width;
mg_rate = 1.5;
gap_height = (1 - rows * height) / (rows - 1 + 2 * mg_rate);
margin_height = mg_rate * gap_height;
lefts = margin_width + (0:cols - 1) * (width + gap_width) + 0.1 * margin_width;
bottoms = margin_height + (rows - 1:-1:0) * (height + gap_height) + 0.1 * margin_height;
poses = zeros(rows * cols,4);
for i = 1:rows
    for j = 1:cols
        poses((i-1) * cols + j,:) = [lefts(j),bottoms(i),width,height];
    end
end
% plot on by one
for i = 1:cols
    for j = 1:length(Indices{i}.Names)
        if strcmp(ModelNames{i},'DPCA') && strcmp(Indices{i}.Names{j},'W')
            xlabel('Sample Number','FontSize',FontSize);
            continue;
        end
        subplot('Position',poses((j - 1) * cols + i,:));
        plot(t_moni,Indices{i}.indexcurves{j});
        hold on;
        plot([t_moni(1),t_moni(length(t_moni))],CLs{i}(j) * [1,1],'--','color',CL_color);
        xlim([t_moni(1),max(t_moni)]);
        ylim_this = ylim();
        ylim_this(1) = 0;
%         if i == 2 && j == 2
%             ylim_this(2) = 200;
%         end
        hold on;
        plot([t_fs,t_fs],ylim_this,'r--');
        hold on;
        plot([t_fe,t_fe],ylim_this,'r--');
        ylim(ylim_this);
        hold off;
        set(gca,'FontSize',FontSize_axis);
        if strcmp(Indices{i}.Names{j},'SPE')
            ylabel('Q','FontSize',FontSize);
        else
            ylabel(Indices{i}.Names{j},'FontSize',FontSize);
        end
%         ylabel(Indices{i}.Names{j},'FontSize',FontSize);
        if j == length(Indices{i}.Names)
            xlabel('Sample Number','FontSize',FontSize);
        end
        if j == 1
            title(ModelNames{i},'FontSize',FontSize);
        end
    end
end
return;
end

