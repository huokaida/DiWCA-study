%% Plot SPM
FontSize = 18;
FontSize_axis = 14;
DrawSPM(ModelNames,Indices,CLs,t_moni,t_fs,t_fe);