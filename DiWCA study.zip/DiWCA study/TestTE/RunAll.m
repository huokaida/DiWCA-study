% TE modeling and monitoring
load('CSTRTrainingData.mat');
load('TEMSPM_model.mat');
% run ModelingTE;
% load('TETestData_XMV5_0.1.mat');
load('TETestData_IDV3_0.5.mat');
run MonitoringTE;
run DrawPicsTE;