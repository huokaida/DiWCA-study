%% modeling
my = 22;
mu = 9;
% DiPCA��ģ
Model_DiPCA = DiPCAtrain(CLX_,3);
% DiCCA��ģ
Model_DiCCA = DiCCAtrain(CLX_,3);
% DiWCA��ģ
Model_DiWCA = DiWCAtrain(CLX_,3,0.05);


%% determine control limits
L = 80; % width of window
[~,CLs_DiPCA] = monitoringDiPCA(CLX_,Model_DiPCA);
[~,CLs_DiCCA] = monitoringDiCCA(CLX_,Model_DiCCA);
[~,CLs_DiWCA] = monitoringDiWCA(CLX_,Model_DiWCA,L);