%% generate Data
% % collect normal Data for modeling
% Ts = 1;
% TrainX = CSTRNormalData_generate(100,Ts,0.05,0.05,0.001,0.001);
% % collect normal Data for determining control limits
% CLX = CSTRNormalData_generate(500,Ts,0.05,0.05,0.001,0.001);
% % normalize
% meanTrainX = mean(TrainX);
% stdTrainX = std(TrainX);
% TrainX_n = TrainX - ones(size(TrainX,1),1) * meanTrainX;
% CLX_n = (CLX - ones(size(CLX,1),1) * meanTrainX);
% TrainX_ = TrainX_n ./ (ones(size(TrainX,1),1) * stdTrainX);
% CLX_ = CLX_n ./ (ones(size(CLX,1),1) * stdTrainX);

% % generate Test Data
% Ts = 1;
% [TestX,~,t_fs,t_fe] = CSTRFaultData_generate(700,Ts,0.05,0.05,0.001,0.001);
% TestX_n = TestX - ones(size(TestX,1),1) * meanTrainX;
% TestX_ = TestX_n ./ (ones(size(TestX,1),1) * stdTrainX);