%% monitor
ModelNames = {'DiPCA','DiCCA','DiWCA'};
t_moni = 0:size(TestX,1) - 1;
L = 80; %width of window
Models = cell(1,length(ModelNames));
Indices = cell(1,length(ModelNames));
CLs = cell(1,length(ModelNames));
for i = 1:length(ModelNames)
    if strcmp(ModelNames{i},'DiPCA')
        Indices_DiPCA = monitoringDiPCA(TestX_,Model_DiPCA);
        Indices{i} = Indices_DiPCA;
        Models{i} = Model_DiPCA;
        CLs_this = zeros(1,length(Indices_DiPCA.Names));
        if length(CLs_DiPCA) == 3
            for j = 1:length(Indices_DiPCA.Names)
                if strcmp(Indices_DiPCA.Names{j},'\phi_e')
                    CLs_this(j) = CLs_DiPCA(1);
                end
                if strcmp(Indices_DiPCA.Names{j},'\phi_r')
                    CLs_this(j) = CLs_DiPCA(2);
                end
                if strcmp(Indices_DiPCA.Names{j},'\phi_v')
                    CLs_this(j) = CLs_DiPCA(3);
                end
            end
        end
        if length(CLs_DiPCA) == 2
            for j = 1:length(Indices_DiPCA.Names)
                CLs_this(j) = CLs_DiPCA(j);
            end
        end
        CLs{i} = CLs_this;
    end
    if strcmp(ModelNames{i},'DiCCA')
        Indices_DiCCA = monitoringDiCCA(TestX_,Model_DiCCA);
        Indices{i} = Indices_DiCCA;
        Models{i} = Model_DiCCA;
        CLs_this = zeros(1,length(Indices_DiCCA.Names));
        if length(CLs_DiCCA) == 3
            for j = 1:length(Indices_DiCCA.Names)
                if strcmp(Indices_DiCCA.Names{j},'\phi_e')
                    CLs_this(j) = CLs_DiCCA(1);
                end
                if strcmp(Indices_DiCCA.Names{j},'\phi_r')
                    CLs_this(j) = CLs_DiCCA(2);
                end
                if strcmp(Indices_DiCCA.Names{j},'\phi_v')
                    CLs_this(j) = CLs_DiCCA(3);
                end
            end
        end
        if length(CLs_DiCCA) == 2
            for j = 1:length(Indices_DiCCA.Names)
                CLs_this(j) = CLs_DiCCA(j);
            end
        end
        CLs{i} = CLs_this;
    end
    if strcmp(ModelNames{i},'DiWCA')
        Indices_DiWCA = monitoringDiWCA(TestX_,Model_DiWCA,L);
        Indices{i} = Indices_DiWCA;
        Models{i} = Model_DiWCA;
        CLs{i} = CLs_DiWCA;
    end
end