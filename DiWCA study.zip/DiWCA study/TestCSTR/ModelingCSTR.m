%% model
% % DiPCA
Model_DiPCA = DiPCAtrain(TrainX_,2);
% % DiCCA
% Model_DiCCA = DiCCAtrain(TrainX_,3);
Model_DiCCA = DiCCAtrain(TrainX_,2);
% % DiWCA
% Model_DiWCA = DiWCAtrain(TrainX_,3);
Model_DiWCA = DiWCAtrain(TrainX_,2);


%% determine control limits
L = 80; % width of window
[~,CLs_DiPCA] = monitoringDiPCA(CLX_,Model_DiPCA);
[~,CLs_DiCCA] = monitoringDiCCA(CLX_,Model_DiCCA);
[~,CLs_DiWCA] = monitoringDiWCA(CLX_,Model_DiWCA,L);