%% Plot SPM
FontSize = 18;
FontSize_axis = 14;
DrawSPM(ModelNames,Indices,CLs,t_moni,t_fs,t_fe);
% yLims = [NaN,NaN,100,100,NaN,NaN,20,100,NaN];
% DrawSPM_YlimGiven(ModelNames,Indices,CLs,t_moni,t_fs,t_fe,yLims);