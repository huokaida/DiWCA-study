function [X] = CSTRNormalData_generate(NumofSamples,Ts,sigma_v1,sigma_v2,s1,s2)
% CSTR simulation

k_pre = 200;
t_end = (NumofSamples + k_pre) * Ts;
t = 0:Ts:t_end;
t = t';
N = size(t, 1);
b = ones(N, 1);
C_Af = 1;
T_f = 400;

v1 = sigma_v1 * randn(N, 1);
v2 = sigma_v2 * randn(N, 1);

Noise = zeros(N,4);
Noise(:,1) = s1 * randn(N,1);
Noise(:,2) = s2 * randn(N,1);

k0 = 6.6 * 10^5;
ut = [t, C_Af * b, T_f * b, v1, v2, 100 * ones(N, 1) k0 * ones(N, 1)];
[~, x2, y2] = sim('CSTRmodel', t_end, [], ut);
E2 = x2(:,1:2) - y2(:,1:2);
ite = 0;
X = zeros(NumofSamples + k_pre + 1, 4);
E = zeros(NumofSamples + k_pre + 1, 2);
X_downsample = zeros(NumofSamples + k_pre + 1, 2);
for t = 0:Ts:t_end
    index = round(t * 100 + 1);
    ite = ite + 1;
    X(ite, :) = y2(index, :) + Noise(ite,:);
    E(ite,:) = E2(index,:);
    X_downsample(ite,:) = x2(index,1:2);
end
X = X(k_pre:NumofSamples + k_pre + 1,:);
E = E(k_pre:NumofSamples + k_pre + 1,:);
X_downsample = X_downsample(k_pre:NumofSamples + k_pre + 1,:);
return;
end

