% CSTR modeling and monitoring
load('CSTRTrainingData.mat');
% load('CSTRLVmodels.mat');
run ModelingCSTR;
load('CSTRTestData_k0drift_6.5_noise0.001_adnoise0.05.mat');
% load('CSTRTestData_dvenlarged_twice_noise0.001_adnoise0.05.mat');
run MonitoringCSTR;
run DrawPicsCSTR;