function [X,param_changed,k_fs,k_fe] = CSTRFaultData_generate(NumofSamples,Ts,sigma_v1,sigma_v2,s1,s2,k_fs,k_fe)
% CSTR simulation (fault)

if nargin < 7
    k_fs = 200;
    k_fe = 500;
end
k_pre = k_fs;

t_end = (NumofSamples + k_pre) * Ts;
t = 0:Ts:t_end;
t = t';
N = size(t, 1);
b = ones(N, 1);
C_Af = 1;
T_f = 400;

v1 = sigma_v1 * randn(N, 1);
v2 = sigma_v2 * randn(N, 1);

Noise = zeros(N,4);
Noise(:,1) = s1 * randn(N,1);
Noise(:,2) = s2 * randn(N,1);

% % 
% k0 = 6.6 * 10^5;
% k0_fault = 6.4 * 10^5;
% k0Disturbance = (100:(-1):1)' / 100 * (k0 - k0_fault) + k0_fault;
% k0Disturbance = [k0 * ones(k_fs + k_pre + 1, 1); k0Disturbance; k0_fault * ones(k_fe - k_fs - 100, 1); k0 * ones(NumofSamples - k_fe, 1)]; 
% ut = [t, C_Af * b, T_f * b, v1, v2, 100 * ones(N, 1), k0Disturbance];
% param_changed = k0Disturbance;

% % 
% k0 = 6.6 * 10^5;
% T_fDisturbance = [T_f * ones(k_fs + k_pre + 1, 1); (T_f + 0.5) * ones(k_fe - k_fs, 1); T_f * ones(NumofSamples - k_fe, 1)];
% ut = [t, C_Af * b, T_fDisturbance, v1, v2, 100 * ones(N, 1), k0 * ones(N, 1)];
% param_changed = T_fDisturbance;

% % 
% k0 = 6.6 * 10^5;
% C_Af = C_Af * b;
% C_Af(k_fs + k_pre:k_fe + k_pre) = 0.9 * C_Af(k_fs + k_pre:k_fe + k_pre);
% ut = [t, C_Af, T_f * b, v1, v2, 100 * ones(N, 1) k0 * ones(N, 1)];
% param_changed = C_Af;

% % 
% s_Caf = 0.001;
% v_Caf = s_Caf * randn(N,1);
% v_Caf(k_fs + k_pre:k_fe + k_pre,1) = 10 * s_Caf * randn(k_fe - k_fs + 1,1);
% k0 = 6.6 * 10^5;
% C_Af = C_Af * b + v_Caf;
% ut = [t, C_Af, T_f * b, v1, v2, 100 * ones(N, 1) k0 * ones(N, 1)];
% param_changed = C_Af;

% % 
% % v1(k_fs + k_pre:k_fe + k_pre) = 2 * sigma_v1 * randn(k_fe - k_fs + 1, 1);
% % v2(k_fs + k_pre:k_fe + k_pre) = 2 * sigma_v2 * randn(k_fe - k_fs + 1, 1);
% v1(k_fs + k_pre:k_fe + k_pre) = 2 * v1(k_fs + k_pre:k_fe + k_pre);
% v2(k_fs + k_pre:k_fe + k_pre) = 2 * v2(k_fs + k_pre:k_fe + k_pre);
% k0 = 6.6 * 10^5;
% ut = [t, C_Af * b, T_f * b, v1, v2, 100 * ones(N, 1) k0 * ones(N, 1)];
% param_changed = [v1,v2];

% % 
% Noise(k_fs + k_pre:k_fe + k_pre,1) = 3 * s1 * randn(k_fe - k_fs + 1,1);
% Noise(k_fs + k_pre:k_fe + k_pre,2) = 3 * s2 * randn(k_fe - k_fs + 1,1);
% k0 = 6.6 * 10^5;
% ut = [t, C_Af * b, T_f * b, v1, v2, 100 * ones(N, 1) k0 * ones(N, 1)];
% param_changed = Noise;

% % normal
% k0 = 6.6 * 10^5;
% ut = [t, C_Af * b, T_f * b, v1, v2, 100 * ones(N, 1) k0 * ones(N, 1)];
% param_changed = NaN;

[~, x2, y2] = sim('CSTRmodel', t_end, [], ut);
E2 = x2(:,1:2) - y2(:,1:2);
ite = 0;
X = zeros(NumofSamples + k_pre + 1, 4);
E = zeros(NumofSamples + k_pre + 1, 2);
X_downsample = zeros(NumofSamples + k_pre + 1, 2);
for t = 0:Ts:t_end
    index = round(t * 100 + 1);
    ite = ite + 1;
    X(ite, :) = y2(index, :) + Noise(ite,:);
    E(ite,:) = E2(index,:);
    X_downsample(ite,:) = x2(index,1:2);
end
X = X(k_pre:NumofSamples + k_pre + 1,:);
E = E(k_pre:NumofSamples + k_pre + 1,:);
X_downsample = X_downsample(k_pre:NumofSamples + k_pre + 1,:);
return;
end

