"Algorithm" contains codes for DiPCA, DiCCA, DiWCA modeling and monitoring.
"DrawPics" contains codes for drawing figures.
"TestCSTR" contains codes for CSTR case studies, including data generating, modeling, monitoring and data files.
"TestTE" contains codes for CSTR case studies, including modeling, monitoring and data files.